# Ofir Portfolio V2

מערכת חדשה לניהול תיק השקעות משפחתי: Google Sheets להזנת נתונים, Apps Script לעיבוד ושליחת טלגרם, ו-Next.js/Vercel להצגת דשבורד מאובטח.

## מה יש כאן

- `app/` - אתר Next.js מוכן ל-Vercel.
- `app/api/portfolio/route.ts` - API פנימי שמושך נתונים מ-Apps Script בלי לחשוף סודות לדפדפן.
- `google-apps-script/Code.gs` - סקריפט שיוצר Google Sheet חדש, קורא ממנו נתונים, ומכין הודעת טלגרם.
- `docs/sheets-schema.md` - מבנה הגיליונות והעמודות.
- `.env.example` - משתני סביבה ל-Vercel.

## הרצה מקומית

```bash
npm install
npm run dev
```

האתר יעלה עם נתוני דמו כל עוד לא הוגדרו משתני סביבה.

## פריסה ב-Vercel

1. העלה את התיקייה הזו לריפו GitHub חדש.
2. חבר את הריפו ל-Vercel.
3. הגדר ב-Vercel את משתני הסביבה מתוך `.env.example`.
4. פרוס מחדש.

## הקמת Google Sheets חדש

1. פתח Apps Script חדש: https://script.google.com
2. הדבק את התוכן של `google-apps-script/Code.gs`.
3. הרץ את `createPortfolioWorkbook`.
4. שמור את כתובת הגיליון החדש.
5. הרץ `setInitialScriptProperties` פעם אחת ועדכן שם את הערכים לפני ההרצה.
6. פרוס כ-Web App עם גישה רק למי שמחזיק את הכתובת, כי ה-API עדיין מוגן על ידי `API_SECRET`.

## העיקרון האבטחתי

הדפדפן מדבר רק עם `/api/portfolio`. רק השרת של Vercel יודע את `APPS_SCRIPT_URL` ואת `APPS_SCRIPT_SECRET`, ורק Apps Script יודע את הטוקנים של Telegram/IBKR.
