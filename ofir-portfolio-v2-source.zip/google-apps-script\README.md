# Apps Script Setup

1. Create a new Apps Script project.
2. Paste `Code.gs`.
3. Run `createPortfolioWorkbook`.
4. Copy the spreadsheet URL from the logs.
5. Edit `setInitialScriptProperties` with real values and run it once.
6. Deploy as Web App.
7. Copy the Web App URL into Vercel as `APPS_SCRIPT_URL`.

Use the same random value for:

- Apps Script `API_SECRET`
- Vercel `APPS_SCRIPT_SECRET`

Keep Telegram and IBKR tokens only in Script Properties.
